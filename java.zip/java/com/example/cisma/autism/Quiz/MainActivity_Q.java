package com.example.cisma.autism.Quiz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cisma.autism.R;

public class MainActivity_Q extends AppCompatActivity {

    private Questionlib questions=new Questionlib();
    private TextView score;
    private TextView questionview;
    private Button choice1;
    private Button choice2;
    private Button choice3;
    private Button choice4;
    private Button quit;

    private String answer;
    private int ascore=0;
    private int qustno=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gk);

        score=(TextView)findViewById(R.id.number);
        questionview=(TextView)findViewById(R.id.text);
        choice1=(Button)findViewById(R.id.button);
        choice2=(Button)findViewById(R.id.button2);
        choice3=(Button)findViewById(R.id.button3);
        choice4=(Button)findViewById(R.id.button4);
        quit=(Button)findViewById(R.id.button6);

        choice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(choice1.getText()== answer){
                    Log.i("Score",ascore+"");
                    ascore=ascore+1;
                    Log.i("Score",ascore+"");
                    updatescore(ascore);
                    updatequest();
                    Toast.makeText(MainActivity_Q.this,"Correct Answer",Toast.LENGTH_SHORT).show();

                }
                else{
                    Toast.makeText(MainActivity_Q.this,"Wrong Answer",Toast.LENGTH_SHORT).show();
                    updatequest();
                }
            }
        });

        choice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(choice2.getText()== answer){
                    Log.i("Score",ascore+"");
                    ascore=ascore+1;
                    Log.i("Score",ascore+"");
                    updatescore(ascore);
                    updatequest();
                    Toast.makeText(MainActivity_Q.this,"Correct Answer",Toast.LENGTH_SHORT).show();

                }
                else{
                    Toast.makeText(MainActivity_Q.this,"Wrong Answer",Toast.LENGTH_SHORT).show();
                    updatequest();
                }
            }
        });

        choice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(choice3.getText()== answer){
                    Log.i("Score",ascore+"");
                    ascore=ascore+1;
                    Log.i("Score",ascore+"");
                    updatescore(ascore);
                    updatequest();
                    Toast.makeText(MainActivity_Q.this,"Correct Answer",Toast.LENGTH_SHORT).show();

                }
                else{
                    Toast.makeText(MainActivity_Q.this,"Wrong Answer",Toast.LENGTH_SHORT).show();
                    updatequest();
                }


            }
        });

        choice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(choice4.getText()== answer){
                    Log.i("Score",ascore+"");
                    ascore=ascore+1;
                    Log.i("Score",ascore+"");
                    updatescore(ascore);
                    updatequest();

                    Toast.makeText(MainActivity_Q.this,"Correct Answer",Toast.LENGTH_SHORT).show();


                }
                else{
                    Toast.makeText(MainActivity_Q.this,"Wrong Answer",Toast.LENGTH_SHORT).show();
                    updatequest();
                }
            }
        });

        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                Intent i=new Intent(MainActivity_Q.this,Quit.class);
                startActivity(i);

            }

        });


    };

    private void updatequest(){
        questionview.setText(questions.getquest(qustno));
        choice1.setText(questions.getchoice1(qustno));
        choice2.setText(questions.getchoice2(qustno));
        choice3.setText(questions.getchoice3(qustno));
        choice4.setText(questions.getchoice4(qustno));

        answer=questions.getanswer(qustno);
        qustno++;

    }

    private void updatescore(int point){
        Log.i("up Score",ascore+"");
        String s=ascore+"";
        score.setText(s);
        Log.i("up Score",ascore+"");

    }

}
