package com.example.cisma.autism.Quiz;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by Intel on 3/22/2017.
 */

public class Questionlib extends AppCompatActivity {

    private String questions[]={
            "What is the capital of Nepal?",
            "Janga BD.Rana was the frist pm of Nepal to visit Europe,then who was the first king to visit Europe?",
            "Who invented telephone?",
            "Who is the author of book Romeo N Juliet?",
            "When is UNO day celebrated?",
            "Who is the elected supremo of the Nepali political party Nepali congress?",
            "Which mountainers ,for the first time was,opened to be climbed for the mountaieers in Nepal?",
            "Which game does David Beckam play?",
            "Who is the author of book Nepali Ramayan?",
            "Who was the first president of Nepal",
            "Who invented radio?",
            "Who is the author of book muna madan?",
            "Who was the first president of America?",
            "what is the capital of canada?",
            "When is democracy day being celebrated in Nepal?",
            "Where is the mount Everest situated?"

    };

    private String options[][]={
            {"Kathmandu","Birganj","Dharan","Pokhara"},
            {"King gyanendra","King Mahendra","King birendra","King Tribhuwan"},
            {"Einstein","Benjamin","Graham","Franklin"},
            {"Shakespayer","William","Ram","Shyam"},
            {"November 24","October 24","January 24","March 24"},
            {"BP koirala","Prachanda","Sushil koirala","Oli"},
            {"Gaurishankar","Annapurna","Ganesh himal","Machapuchre"},
            {"Tennis","Football","Swimming","Cricket"},
            {"Bhanu Bhakta Acharya","LekhNath Poudel","Laxmi pd Devkota","Valmiki"},
            {"Prachanda","Oli","Ram Baran Yadav","BP koirala"},
            {"Graham","Marcony","Franklin","Einstein"},
            {"Bhanu Bhakta Acharya","LekhNath Poudel","Laxmi pd Devkota","Valmiki"},
            {"Trump","Bush","Obama","George Washington"},
            {"Ottawa","sydney","Washington","Nigeria"},
            {"Falgun27","Flagun7","Falgun17","Falgun 15"},
            {"Russia","America","Nepal","China"}

    };

    private String answer[]={"Kathmandu","King Tribhuwan","Graham","Shakespayer","October24","Sushil koirala","Annapurna","Football",
            "Bhanu Bhakta Acharya","Ram Baran Yadav","Marcony","Laxmi pd Devkota","George Washington","Ottawa","Falfun7","Nepal"};

    public String getquest(int a){
        String question=questions[a];
        return question;
    }

    public String getchoice1(int a){
        String choice0=options[a][0];
        return choice0;
    }

    public String getchoice2(int a){
        String choice1=options[a][1];
        return choice1;
    }

    public String getchoice3(int a){
        String choice2=options[a][2];
        return choice2;
    }
    public String getchoice4(int a){
        String choice3=options[a][3];
        return choice3;
    }

    public String getanswer(int a){
        String answers=answer[a];
        return answers;
    }


}

