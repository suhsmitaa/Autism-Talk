package com.example.cisma.autism.Quiz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.cisma.autism.R;

/**
 * Created by Intel on 3/22/2017.
 */

public class Quit extends AppCompatActivity {

    private Button quit;
    private TextView score;

    private int ascore=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quit);

        quit=(Button)findViewById(R.id.button5);
        score=(TextView)findViewById(R.id.zero);
        updatescore(0);


        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("Score",ascore+"");
                ascore=ascore+1;
                Log.i("Score",ascore+"");
                updatescore(ascore);
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                System.exit(0);
            }
        }); }

    private void updatescore(int point) {
        Log.i("up Score",ascore+"");
        String s=ascore+"";
        score.setText(s);
        Log.i("up Score",ascore+"");
    }






}
