package com.example.cisma.autism.Start;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.cisma.autism.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

/**
 * Created by Intel on 7/20/2017.
 */

public class Register extends AppCompatActivity implements View.OnClickListener {

    private EditText eFirstname,eLastname,eage,eName,eRelation,eUsername,ePassword,eRepassword;
    private Button submit;
    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAuth;
    public static FirebaseDatabase mdatabase;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        firebaseAuth = FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser()!=null){
            finish();
            Intent i = new Intent(Register.this, Login.class);
            startActivity(i);

        }


        progressDialog = new ProgressDialog(this);
        submit = (Button)findViewById(R.id.submit);




    }

    public void onClick(View v) {

        if(v.getId()== R.id.submit) {
            final EditText eFirstname = (EditText) findViewById(R.id.eFirstname);
            EditText eLastname = (EditText) findViewById(R.id.eLastname);
            EditText eage = (EditText) findViewById(R.id.eage);
            EditText eName = (EditText) findViewById(R.id.eName);
            EditText eRelation = (EditText) findViewById(R.id.eRelation);
            EditText eUsername = (EditText) findViewById(R.id.eUsername);
            EditText ePassword = (EditText) findViewById(R.id.ePassword);
            EditText eRepassword = (EditText) findViewById(R.id.eRepassword);

            String fnamestr = eFirstname.getText().toString();
            String lnamestr = eLastname.getText().toString();
            String namestr = eName.getText().toString();
            String agestr = eage.getText().toString();
            String relstr = eRelation.getText().toString();
            String email = eUsername.getText().toString().trim();
            String password = ePassword.getText().toString().trim();
            String pass2str = eRepassword.getText().toString();

            if(TextUtils.isEmpty(fnamestr)&& TextUtils.isEmpty(lnamestr) && TextUtils.isEmpty(agestr) && TextUtils.isEmpty(namestr) && TextUtils.isEmpty(relstr) && TextUtils.isEmpty(email) && TextUtils.isEmpty(password) && TextUtils.isEmpty(pass2str)){
                Toast pass= Toast.makeText(Register.this,"please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }

            if(TextUtils.isEmpty(fnamestr)){
                Toast pass= Toast.makeText(Register.this,"please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }
            if(TextUtils.isEmpty(lnamestr)){
                Toast pass= Toast.makeText(Register.this,"please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }
            if(TextUtils.isEmpty(agestr)){
                Toast pass= Toast.makeText(Register.this,"please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }
            if(TextUtils.isEmpty(namestr)){
                Toast pass= Toast.makeText(Register.this,"please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }
            if(TextUtils.isEmpty(relstr)){
                Toast pass= Toast.makeText(Register.this,"please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }
            if(TextUtils.isEmpty(email)){
                Toast pass= Toast.makeText(Register.this," please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }
            if(TextUtils.isEmpty(password)){
                Toast pass= Toast.makeText(Register.this," please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }
            if(TextUtils.isEmpty(pass2str)){
                Toast pass= Toast.makeText(Register.this,"please enter all fields", Toast.LENGTH_SHORT);
                pass.show();
            }

            if(!password.equals(pass2str)){
                Toast pass= Toast.makeText(Register.this,"password doesn't match", Toast.LENGTH_SHORT);
                pass.show();
            }

            firebaseAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                userProfile();



                                FirebaseUser user = firebaseAuth.getCurrentUser();
                                String UserID=user.getEmail().replace("@","").replace(".","");
                                DatabaseReference mRootRef = FirebaseDatabase.getInstance().getReference();

                                DatabaseReference ref1= mRootRef.child("Users").child(UserID);

                                ref1.child("Name").setValue(eFirstname.getText().toString().trim());
                                ref1.child("Image_Url").setValue("Null");
                                ref1.child("Email").setValue(user.getEmail());

                                Toast pass = Toast.makeText(Register.this, "Registered successfully", Toast.LENGTH_SHORT);
                                pass.show();
                                Intent i = new Intent(Register.this, List.class);
                                startActivity(i);
                            } else {
                                Toast pass = Toast.makeText(Register.this, "Failed to Register"+task.getException(), Toast.LENGTH_SHORT);
                                pass.show();
                            }
                        }
                    });




        }
    }

    private void userProfile() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if(user!= null)
        {
            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                    .setDisplayName(eFirstname.getText().toString().trim())
                    //.setPhotoUri(Uri.parse("https://example.com/jane-q-user/profile.jpg"))  // here you can set image link also.
                    .build();

            user.updateProfile(profileUpdates)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d("TESTING", "User profile updated.");
                            }
                        }
                    });
        }
    }
}
