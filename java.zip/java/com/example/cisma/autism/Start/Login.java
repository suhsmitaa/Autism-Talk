package com.example.cisma.autism.Start;

import android.app.ProgressDialog;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.cisma.autism.MainActivity;
import com.example.cisma.autism.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.onesignal.OneSignal;

/**
 * Created by cisma on 7/23/2017.
 */

public class Login extends AppCompatActivity {

    Button login, register;
    EditText email, password;

    private FirebaseAuth mauth;
    private Image image;
    FirebaseUser user;
    static String LoggedIn_User_Email;
    public static FirebaseDatabase mdatabase;
    private ProgressDialog progressdialog;
    private DatabaseReference databaseref;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        OneSignal.startInit(this).init();
        mauth = FirebaseAuth.getInstance();

        if (mdatabase == null) {
            mdatabase = FirebaseDatabase.getInstance();
            FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        }

        databaseref = FirebaseDatabase.getInstance().getReference();

        progressdialog = new ProgressDialog(this);

        register = (Button) findViewById(R.id.register);
        login = (Button) findViewById(R.id.login);
        email = (EditText) findViewById(R.id.eUsername);
        password = (EditText) findViewById(R.id.ePassword);


        if (mauth.getCurrentUser() != null) {
            //User NOT logged In
            finish();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }

        user = mauth.getCurrentUser();
        Log.d("LOGGED", "user: " + user);


        //Setting the tags for Current User.
        if (user != null) {
            LoggedIn_User_Email = user.getEmail();
        }
        OneSignal.sendTag("User_ID", LoggedIn_User_Email);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callsignin();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Login.this,Register.class);
                startActivity(i);
            }
        });
    }

    private void callsignin() {

        String getemail=email.getText().toString().trim();
        String getpassword=password.getText().toString().trim();




        if(TextUtils.isEmpty(getemail)){
            Toast.makeText(Login.this,"Please enter email",Toast.LENGTH_SHORT).show();
            return;
        }

        if(TextUtils.isEmpty(getpassword)){
            Toast.makeText(Login.this,"Please enter password",Toast.LENGTH_SHORT).show();
            return;
        }

        progressdialog.setMessage("loging");
        progressdialog.show();

        mauth.signInWithEmailAndPassword(getemail,getpassword)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressdialog.dismiss();


                        //Toast.makeText(MainActivity.this,"Login sucessfull",Toast.LENGTH_SHORT).show();
                        if(task.isSuccessful()){

                            Toast.makeText(Login.this,"Login sucessfull",Toast.LENGTH_SHORT).show();
                            Intent i=new Intent(Login.this,MainActivity.class);
                            finish();
                            startActivity(i);
                        }
                        else{
                            Log.e("ERROR",task.getException().toString());
                            Toast.makeText(Login.this,task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }



                    }
                });
    }
}