package com.example.cisma.autism.Paint;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/**
 * Created by cisma on 6/11/2017.
 */
public class Pot extends View implements View.OnTouchListener{

    private final int defaultdotsize=10;
    private final int maxdotsize=100;
    private final int mindotsize=5;
    private final int defaultcolor= Color.WHITE;
    private int dotsize;
    private int mpencolour;
    private ArrayList<Path> mpaths;
    private ArrayList<Paint> mpaints;
    private Path mpath;
    private Paint mpaint;
    private float x ,y,moldx,moldy;


    public Pot(Context context) {
        super(context);
        this.init();
    }



    public Pot(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.init();
    }

    public Pot(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.init();
    }

    private void init() {
        dotsize=defaultdotsize;
        mpencolour=defaultcolor;
        this.mpaths=new ArrayList<Path>();
        this.mpaints=new ArrayList<Paint>();
        mpath=new Path();
        this.addPath(false);
        this.x=this.y=this.moldx=this.moldy=(float)0.0;
        this.setOnTouchListener(this);
    }
    private void addPath(boolean fill){
        mpath=new Path();
        mpaths.add(mpath);
        mpaint=new Paint();
        mpaints.add(mpaint);
        mpaint.setColor(mpencolour);
        if(!fill)
        mpaint.setStyle(Paint.Style.STROKE);
        mpaint.setStrokeWidth(dotsize);
    }

    public int getDotsize() {
        return dotsize;
    }

    public int getpencolour() {
        return mpencolour;
    }

    public void setpencolour(int pencolour) {
        this.mpencolour = pencolour;

    }

    public void changeDotsize(int increment) {
        this.dotsize += increment;
        this.dotsize  = Math.max(dotsize, mindotsize);
        this.dotsize  = Math.min(dotsize, maxdotsize);
    }

    public void reset() {
        this.init();
        this.invalidate();
    }

    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        for(int i=0; i<mpaths.size();++i)
        canvas.drawPath(mpaths.get(i),mpaints.get(i));
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        x=motionEvent.getX();
        y=motionEvent.getY();
        Log.d("Touched:","("+ x +","+ y +")");

        switch(motionEvent.getAction()) {

            case MotionEvent.ACTION_DOWN:
                this.addPath(false);
                this.mpath.moveTo(x,y);
                break;

            case MotionEvent.ACTION_MOVE:
                this.mpath.lineTo(x,y);
                break;
            case MotionEvent.ACTION_UP:
                this.addPath(true);
                if(moldx==x && moldy==y)
                    this.mpath.addCircle(x,y,dotsize/2, Path.Direction.CW);
                break;
        }
        this.invalidate();
        moldx=x;
        moldy=y;
        return true;
    }
}
