package com.example.cisma.autism.Paint;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.cisma.autism.R;

public class MainActivity_P extends AppCompatActivity implements View.OnClickListener{

    private Pot drawingpad;
    private Button red,blue,green,reset,plus,minus,white;
    private TextView dotsize;
    public static final int DOT_INCREMENT=5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paint);
        this.init();
    }

    private void init() {

        drawingpad=(Pot)findViewById(R.id.drawingpad);
        red=(Button)findViewById(R.id.redb);
        blue=(Button)findViewById(R.id.blueb);
        green=(Button)findViewById(R.id.greenb);
        reset=(Button)findViewById(R.id.reset);
        plus=(Button)findViewById(R.id.plus);
        minus=(Button)findViewById(R.id.minus);
        white=(Button)findViewById(R.id.white);


        red.setOnClickListener(this);
        blue.setOnClickListener(this);
        green.setOnClickListener(this);
        reset.setOnClickListener(this);
        plus.setOnClickListener(this);
        minus.setOnClickListener(this);
        white.setOnClickListener(this);

        dotsize=(TextView)findViewById(R.id.dotsize);
        dotsize.setText("DOT SIZE =" +drawingpad.getDotsize());

    }

    public void onClick(View view){

        Button _b=(Button)findViewById(view.getId());

        switch (view.getId()){
            case R.id.redb:drawingpad.setpencolour(Color.RED);
                Log.d("Button pressed:", _b.getText() + "");
                break;

            case R.id.blueb:drawingpad.setpencolour(Color.BLUE);
                Log.d("Button pressed:", _b.getText() + "");
                break;
            case R.id.greenb:drawingpad.setpencolour(Color.GREEN);
                Log.d("Button pressed:", _b.getText() + "");
                break;
            case R.id.white:drawingpad.setpencolour(Color.WHITE);
                Log.d("Button pressed:", _b.getText() + "");
                break;
            case R.id.reset:drawingpad.reset();
                dotsize.setText("DOT SIZE =" +drawingpad.getDotsize());
                Log.d("Button pressed:", _b.getText() + "");
                break;
            case R.id.minus:drawingpad.changeDotsize(-DOT_INCREMENT);
                dotsize.setText("DOT SIZE =" +drawingpad.getDotsize());
                Log.d("Button pressed:", _b.getText() + "");
                break;
            case R.id.plus:drawingpad.changeDotsize(+DOT_INCREMENT);
                dotsize.setText("DOT SIZE =" +drawingpad.getDotsize());
                Log.d("Button pressed:", _b.getText() + "");
                break;
        }
    }
}
