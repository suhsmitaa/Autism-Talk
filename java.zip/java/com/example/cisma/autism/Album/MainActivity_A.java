package com.example.cisma.autism.Album;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.cisma.autism.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MainActivity_A extends AppCompatActivity {

    private Button load,album;
    private StorageReference mstorage;
    private DatabaseReference mdatabaseref;
    private ImageView image;
    private EditText texti;
    private Uri uri;
    private static final int GALLERY=1234;

    private ProgressDialog mprogress;

    public static final String FB_STORAGE="image/";
    public static final String FB_DATBASE="image";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.album);

        mprogress=new ProgressDialog(this);

        mdatabaseref= FirebaseDatabase.getInstance().getReference(FB_DATBASE);
        mstorage= FirebaseStorage.getInstance().getReference();
        load=(Button)findViewById(R.id.load);
        album=(Button)findViewById(R.id.album);
        texti=(EditText)findViewById(R.id.texti);
        image=(ImageView)findViewById(R.id.imageView);

        album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity_A.this,Imagelistact.class);
                startActivity(i);
            }
        });

        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(Intent.ACTION_PICK);
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i,"select image"),GALLERY);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==GALLERY && resultCode==RESULT_OK && data != null && data.getData() != null){

            uri=data.getData();

            try{

                Bitmap bm= MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                image.setImageBitmap(bm);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    public String getImageext(Uri uri){
        ContentResolver contentResolver=getContentResolver();
        MimeTypeMap mimeTypeMap= MimeTypeMap.getSingleton();
        return  mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    public void save(View v){
        if(uri != null){
            final ProgressDialog dialog= new ProgressDialog(this);
            dialog.setTitle("Uploading iamge");
            dialog.show();


            StorageReference ref=mstorage.child(FB_STORAGE + System.currentTimeMillis() +"."+getImageext(uri));

            ref.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                    dialog.dismiss();//dismis wen suces
                    Toast.makeText(getApplicationContext(),"Image Uploaded", Toast.LENGTH_SHORT).show();
                    Imageuplaod imageuplaod=new Imageuplaod(texti.getText().toString(),taskSnapshot.getDownloadUrl().toString());

                    String uploadId=mdatabaseref.push().getKey();
                    mdatabaseref.child(uploadId).setValue(imageuplaod);

                }
            })
                    .addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       dialog.dismiss();//when error
                       Toast.makeText(getApplicationContext(),e.getMessage(), Toast.LENGTH_SHORT).show();

                   }
               })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                            double progress = (100 * taskSnapshot.getBytesTransferred())/ taskSnapshot.getTotalByteCount();
                            dialog.setMessage("Uploaded" + (int)progress+ "%");
                        }
                    });

        }
      else{
            Toast.makeText(getApplicationContext(),"please select image", Toast.LENGTH_SHORT).show();
        }
    }


}
