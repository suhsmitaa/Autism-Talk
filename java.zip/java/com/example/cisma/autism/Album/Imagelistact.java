package com.example.cisma.autism.Album;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import com.example.cisma.autism.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cisma on 6/11/2017.
 */
public class Imagelistact extends AppCompatActivity {

   private DatabaseReference mdatabaseref;
    private List<Imageuplaod> imglist;
    private ListView lv;
    private Imagelistadapter adapter;
    private ProgressDialog mprogres;


    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.imagelist);

        imglist=new ArrayList<>();
        lv=(ListView)findViewById(R.id.listview);

        mprogres =new ProgressDialog(this);
       mprogres.setMessage("Please wait loading image...");
        mprogres.show();

        mdatabaseref = FirebaseDatabase.getInstance().getReference(MainActivity_A.FB_DATBASE);

        mdatabaseref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mprogres.dismiss();
                 //fetch image from fdb
                for(DataSnapshot snapshot:dataSnapshot.getChildren()){
                    //imageupload class need default onstructor
                    Imageuplaod img=snapshot.getValue(Imageuplaod.class);
                    imglist.add(img);
                }

                adapter=new Imagelistadapter(Imagelistact.this,R.layout.imageitm,imglist);
                lv.setAdapter(adapter);//set adapter for listview
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
             mprogres.dismiss();
            }
        });

    }
}
