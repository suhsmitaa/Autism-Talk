package com.example.cisma.autism.Album;

/**
 * Created by cisma on 6/11/2017.
 */
public class Imageuplaod {

    public String name;
    public String url;


    public String getName(){
        return name;
    }

    public String getUrl(){
        return url;
    }

    public Imageuplaod(String name, String url) {
        this.name=name;
        this.url=url;
    }

    public Imageuplaod(){}
}
