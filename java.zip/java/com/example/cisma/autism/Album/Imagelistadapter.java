package com.example.cisma.autism.Album;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.cisma.autism.R;

import java.util.List;

/**
 * Created by cisma on 6/11/2017.
 */
public class Imagelistadapter extends ArrayAdapter<Imageuplaod> {

    private Activity context;
    private int resource;
    private List<Imageuplaod> listimage;

    public Imagelistadapter(Activity context, int resource, List<Imageuplaod> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        listimage=objects;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();

        View v=inflater.inflate(resource,null);
        TextView txt=(TextView)v.findViewById(R.id.textView);
        ImageView imagev=(ImageView)v.findViewById(R.id.imageView2);

        txt.setText(listimage.get(position).getName());
        Glide.with(context).load(listimage.get(position).getUrl()).into(imagev);
        return v;

    }
}
