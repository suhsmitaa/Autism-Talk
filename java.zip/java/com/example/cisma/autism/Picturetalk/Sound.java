package com.example.cisma.autism.Picturetalk;

/**
 * Created by Intel on 7/21/2017.
 */

public class Sound {
    public Sound(int sound, int image, String name) {
        this.sound = sound;
        this.image = image;
        this.name = name;
    }

    int sound, image;
    String name;
}
