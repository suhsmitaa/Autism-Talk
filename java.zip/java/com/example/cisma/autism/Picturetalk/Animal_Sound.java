package com.example.cisma.autism.Picturetalk;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;


import com.example.cisma.autism.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Intel on 7/21/2017.
 */

public class Animal_Sound extends AppCompatActivity {
    private MediaPlayer mp;
    List<Sound> sounds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.animal_sound);

        sounds.add(new Sound(R.raw.cat_sound, R.drawable.cat1, "Cat"));

        //final MediaPlayer catSoundMediaPlayer = MediaPlayer.create(this, R.raw.cat_sound);
        //final MediaPlayer dogSoundMediaPlayer = MediaPlayer.create(this, R.raw.dog);
        final ImageButton playCatMeow = (ImageButton) this.findViewById(R.id.imageview);
        final ImageButton playDog = (ImageButton) this.findViewById(R.id.imageview1);
        final ImageButton playBird = (ImageButton) this.findViewById(R.id.imageview2) ;
        final ImageButton playTiger = (ImageButton) this.findViewById(R.id.imageview3) ;
        // final ImageButton playGoat = (ImageButton) this.findViewById(R.id.imageview4) ;
        //final ImageButton playHorse = (ImageButton) this.findViewById(R.id.imageview5) ;
        //final ImageButton playElephant = (ImageButton) this.findViewById(R.id.imageview6) ;
        //final ImageButton playCow = (ImageButton) this.findViewById(R.id.imageview7) ;



        playCatMeow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying();
                mp = MediaPlayer.create(Animal_Sound.this, R.raw.cat_sound);
                mp.start();
            }

        });
        playDog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying();
                mp = MediaPlayer.create(Animal_Sound.this, R.raw.dog);
                mp.start();
            }

        });
        playBird.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying();
                mp = MediaPlayer.create(Animal_Sound.this, R.raw.bird);
                mp.start();
            }

        });
        playTiger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying();
                mp = MediaPlayer.create(Animal_Sound.this, R.raw.tiger);
                mp.start();
            }

        });
       /*

         <LinearLayout
            android:id="@+id/goat"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:gravity="center"
            android:orientation="vertical">

            <ImageButton
                android:id="@+id/imageview4"
                android:layout_width="match_parent"
                android:layout_height="match_parent"
                android:src="@drawable/goat1">

            </ImageButton>
        </LinearLayout>

        <LinearLayout
            android:id="@+id/horse"
            android:layout_width="match_parent"

            android:layout_height="wrap_content"
            android:gravity="center"
            android:orientation="vertical">

            <ImageButton
                android:id="@+id/imageview5"
                android:layout_width="match_parent"
                android:layout_height="match_parent"
                android:src="@drawable/horse1">

            </ImageButton>
        </LinearLayout>

        <LinearLayout
            android:id="@+id/elephant"
            android:layout_width="match_parent"

            android:layout_height="wrap_content"
            android:gravity="center"
            android:orientation="vertical">

            <ImageButton
                android:id="@+id/imageview6"
                android:layout_width="match_parent"
                android:layout_height="match_parent"
                android:src="@drawable/elephant1">

            </ImageButton>
        </LinearLayout>

        <LinearLayout
            android:id="@+id/cow"
            android:layout_width="match_parent"

            android:layout_height="wrap_content"
            android:gravity="center"
            android:orientation="vertical">

            <ImageButton
                android:id="@+id/imageview7"
                android:layout_width="match_parent"
                android:layout_height="match_parent"
                android:src="@drawable/cow1">

            </ImageButton>
        </LinearLayout>
       playGoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying();
                mp = MediaPlayer.create(Animal_Sound.this, R.raw.goat);
                mp.start();
            }

        });
        playHorse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying();
                mp = MediaPlayer.create(Animal_Sound.this, R.raw.horse);
                mp.start();
            }

        });
        playElephant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying();
                mp = MediaPlayer.create(Animal_Sound.this, R.raw.elephant);
                mp.start();
            }

        });
        playCow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlaying();
                mp = MediaPlayer.create(Animal_Sound.this, R.raw.cow);
                mp.start();
            }

        }); */

    }
    private void stopPlaying() {
        if (mp != null) {
            mp.stop();
            mp.release();
            mp = null;
        }
    }


}
