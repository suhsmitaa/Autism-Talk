package com.example.cisma.autism.Picturetalk;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.cisma.autism.R;

import java.util.Locale;

/**
 * Created by Intel on 7/21/2017.
 */

public class Animals extends AppCompatActivity {
    TextToSpeech ttsobject;
    private ImageButton cat, dog, tiger, elephant, cow, horse, bird, goat;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.animals);

        cat= (ImageButton)findViewById(R.id.cat);
        dog= (ImageButton)findViewById(R.id.dog);
        tiger= (ImageButton)findViewById(R.id.tiger);
        elephant= (ImageButton)findViewById(R.id.elephant);
        cow= (ImageButton)findViewById(R.id.cow);
        horse= (ImageButton)findViewById(R.id.horse);
        bird= (ImageButton)findViewById(R.id.bird);
        goat= (ImageButton)findViewById(R.id.goat);

        ttsobject = new TextToSpeech(Animals.this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status==TextToSpeech.SUCCESS){
                    ttsobject.setLanguage(Locale.UK);
                }
                else{
                    Toast.makeText(getApplicationContext(),"Feature not supported",Toast.LENGTH_SHORT).show();
                }

            }

        });
    }
    public void ImagebuttonClick(View v){

        String nameofview=v.getResources().getResourceName(v.getId());  // complete view name

        Toast.makeText(getApplicationContext(),nameofview.split("/")[1],Toast.LENGTH_LONG).show();

        ttsobject.speak(nameofview.split("/")[1], TextToSpeech.QUEUE_FLUSH,null);

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(ttsobject!=null){
            ttsobject.stop();
            ttsobject.shutdown();
        }
    }
}

