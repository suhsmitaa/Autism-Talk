package com.example.cisma.autism.Picturetalk;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.cisma.autism.R;

/**
 * Created by Intel on 7/21/2017.
 */

public class Picture_Talk extends AppCompatActivity {

    private Button food, emoticons, vehicles, animal_sounds, animals;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.picture_talk);

        food = (Button)findViewById(R.id.food);
        emoticons = (Button)findViewById(R.id.emoticons);
        vehicles = (Button)findViewById(R.id.vehicles);
        animals = (Button)findViewById(R.id.animals);
        animal_sounds = (Button)findViewById(R.id.animal_sounds);


        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent food = new Intent(Picture_Talk.this,Food.class);
                startActivity(food);
            }
        });

        emoticons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emoticons = new Intent(Picture_Talk.this,Emoticons.class);
                startActivity(emoticons);
            }
        });
        vehicles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent vehicles = new Intent(Picture_Talk.this,Vehicles.class);
                startActivity(vehicles);
            }
        });
        animal_sounds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent animal_sounds = new Intent(Picture_Talk.this, Animal_Sound.class);
                startActivity(animal_sounds);
            }
        });
        animals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent animals = new Intent(Picture_Talk.this, Animals.class);
                startActivity(animals);
            }
        });


    }
}
