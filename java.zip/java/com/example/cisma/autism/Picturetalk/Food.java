package com.example.cisma.autism.Picturetalk;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.cisma.autism.R;

import java.util.Locale;

/**
 * Created by Intel on 7/21/2017.
 */

public class Food extends AppCompatActivity {
    TextToSpeech ttsobject;
    private ImageButton i1, hate1, love2, cookie1, chocolate1, icecream1, pizza, want1, food1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food);

        i1 = (ImageButton) findViewById(R.id.i);
        want1 = (ImageButton) findViewById(R.id.want);
        love2 = (ImageButton) findViewById(R.id.love);
        chocolate1 = (ImageButton) findViewById(R.id.chocolate);
        icecream1 = (ImageButton) findViewById(R.id.icecream);
        pizza = (ImageButton) findViewById(R.id.pizza);
        food1 = (ImageButton) findViewById(R.id.food);
        hate1 = (ImageButton) findViewById(R.id.hate);
        cookie1 = (ImageButton) findViewById(R.id.cookie);


        ttsobject = new TextToSpeech(Food.this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status==TextToSpeech.SUCCESS){
                    ttsobject.setLanguage(Locale.UK);
                }
                else{
                    Toast.makeText(getApplicationContext(),"Feature not supported",Toast.LENGTH_SHORT).show();
                }

            }

        });
    }
    public void ImagebuttonClick(View v){


        /*

        serious note:


        v.getResources().getResourceName(v.getId()) returns view name but of form "com.smartlabsnepal.rubin.text:id/pizza" so

        Split the view using a regex string expression and get the name of the view which is usually the last index in array


        For example com.smartlabsnepal.rubin.text:id/pizza splitting will get you an array of size 2,

        with com.smartlabsnepal.rubin.text:id  in index 0 and pizza in index 1

        see the code below

        */

        String nameofview=v.getResources().getResourceName(v.getId());  // complete view name

        Toast.makeText(getApplicationContext(),nameofview.split("/")[1],Toast.LENGTH_LONG).show();

        ttsobject.speak(nameofview.split("/")[1], TextToSpeech.QUEUE_FLUSH,null);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(ttsobject!=null){
            ttsobject.stop();
            ttsobject.shutdown();
        }
    }
}

