package com.example.cisma.autism.Chat;

/**
 * Created by cisma on 6/19/2017.
 */
public class ShowChatActivity_DataItems {
    private String Email;
    private String Image_Url;
    private String Name;

    public ShowChatActivity_DataItems()
    {
    }

    public ShowChatActivity_DataItems(String email, String image_Url, String name) {
        Email = email;
        Image_Url = image_Url;
        Name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getImage_Url() {
        return Image_Url;
    }

    public void setImage_Url(String image_Url) {
        Image_Url = image_Url;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}
