/*
 * PocketSphinx Continue Recognition Demo
 * Developed by Luis G III
 * e-mail: loiis.x14@gmail.com
 * visit: http://hellospoonpr@gmail.com and get your own HelloSpoon robot!
 * */
package com.example.cisma.autism.Speech;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.TextView;

import com.example.cisma.autism.R;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import edu.cmu.pocketsphinx.Assets;
import edu.cmu.pocketsphinx.Hypothesis;
import edu.cmu.pocketsphinx.RecognitionListener;
import edu.cmu.pocketsphinx.SpeechRecognizer;

import static edu.cmu.pocketsphinx.SpeechRecognizerSetup.defaultSetup;

public class MainActivity_S extends Activity implements RecognitionListener{


	private static final int VOICE_RECOGNITION_REQUEST_CODE = 1234;
	SpeechRecognizer recognizer;
	TextView recognizer_state, recognized_word;
	int conteo = 0;
	int permiso_flag=0;
	Handler a = new Handler();
	String ab;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.speech);

		recognizer_state = (TextView) findViewById(R.id.textView2);
		recognized_word = (TextView) findViewById(R.id.textView3);

		final HashMap<String,String> apps= new HashMap<>();
		apps.put("paint","https://www.facebook.com/");
		apps.put("google","https://www.google.com/");
		apps.put("yahoo","https://www.yahoo.com/");
		apps.put("kaymu","https://www.kaymu.com.np/");
		apps.put("hcoe","https://www.hcoe.edu.np/");





		new AsyncTask<Void, Void, Exception>() {
            @Override
            protected Exception doInBackground(Void... params) {
                try {
                    Assets assets = new Assets(getApplicationContext());
                    File assetDir = assets.syncAssets();
                    setupRecognizer(assetDir);
                } catch (IOException e) {
                    return e;
                }
                return null;
            }

            @Override
            protected void onPostExecute(Exception result) {
                if (result != null) {
                } else {
                	FireRecognition();
                }
            }
        }.execute();

	}

	@Override
	public void onStop(){
		super.onStop();
		recognizer.removeListener(this);
	}


	public void FireRecognition(){
		Log.d("Recognition","Recognition Started");
        recognizer_state.setText("Recognition Started!");
        conteo = 0;
		recognizer.stop();
        recognizer.startListening("digits");
	}

	@Override
	public void onBeginningOfSpeech() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onEndOfSpeech() {
		// TODO Auto-generated method stub

	}



	private void setupRecognizer(File assetsDir) {
	    File modelsDir = new File(assetsDir, "models");
	    recognizer = defaultSetup()
	            .setAcousticModel(new File(modelsDir, "hmm/en-us-semi"))
	            .setDictionary(new File(modelsDir, "dict/cmu07a.dic"))
	            .setRawLogDir(assetsDir).setKeywordThreshold(1e-40f)
	            .getRecognizer();
	    recognizer.addListener(this);


	    File digitsGrammar = new File(modelsDir, "grammar/digits.gram");
	    recognizer.addGrammarSearch("digits", digitsGrammar);

	       }

	@Override
	public void onResult(Hypothesis hup) {
		conteo +=1;
		if(conteo==1){
			//recognizer.stop();
			Timer();
		}
	}

	public void Timer(){
		 new Thread(new Runnable() {
		        @Override
		        public void run() {
		                try {
		                    Thread.sleep(500);
		                    a.post(new Runnable() {
		                        @Override
		                        public void run() {

		                        	FireRecognition();
		                        }
		                    });
		                } catch (Exception e) {
		                }
		            }

		    }).start();
	}

	@Override
	public void onPartialResult(Hypothesis arg0) {
		if(arg0 == null){ return; }
		String comando = arg0.getHypstr();

		recognized_word.setText(comando);

		final HashMap<String,String> apps= new HashMap<>();
		apps.put("paint","https://www.facebook.com/");
		apps.put("google","https://www.google.com/");
		apps.put("yahoo","https://www.yahoo.com/");
		apps.put("kaymu","https://www.kaymu.com.np/");
		apps.put("hcoe","https://www.hcoe.edu.np/");

		Intent intent = null, chooser = null;


		intent = new Intent(android.content.Intent.ACTION_VIEW);
		intent.setData(Uri.parse(apps.get(comando)));
		chooser = Intent.createChooser(intent, "Launch viber");
		startActivity(chooser);


		conteo +=1;
		if(conteo==1){
			conteo = 0;
			Log.d("Res", comando);
			//recognizer.stop();
			Timer();
		}
		
	}



    }


