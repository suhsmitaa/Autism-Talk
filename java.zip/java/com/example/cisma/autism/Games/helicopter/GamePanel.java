package com.example.cisma.autism.Games.helicopter;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.example.cisma.autism.R;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Intel on 7/24/2017.
 */

public class GamePanel extends SurfaceView implements SurfaceHolder.Callback {
    public static final int WIDTH = 856;
    public static final int HEIGHT = 480;
    public static final int MOVESPEED = -15;
    private long smokeStartTime;
    private long missileStartTime;

    private MainThread thread;
    private Background bg;
    private Player player;
    private ArrayList<SmokePuff> smoke;
    private ArrayList<Missile> missiles;
    private ArrayList<TopBorder>topborder;
    private ArrayList<BotBorder>botborder;
    private Random rand = new Random();
    private int maxBorderHeight;
    private int minBorderHeight;
    private boolean topDown=true;
    private boolean botDown=true;
    private boolean newGameCreated;
    private int progressDenom=20;
    private int best;

    public GamePanel(Context context) {
        super(context);
        //add callback to surfaceholder to interrupt events
        getHolder().addCallback(this);

        thread = new MainThread(getHolder(), this);
        setFocusable(true);
    }
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        int counter = 0;
        while (retry && counter < 1000) {
            counter++;
            try {
                thread.setRunning(false);
                thread.join();
                retry = false;
                thread=null;
                //save high score
                SharedPreferences prefs =this.getContext().getSharedPreferences("BEST",Context.MODE_PRIVATE);
                SharedPreferences.Editor editor =prefs.edit();
                editor.putInt("key",best);
                editor.commit();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        bg = new Background(BitmapFactory.decodeResource(getResources(), R.drawable.grass2));
        player = new Player(BitmapFactory.decodeResource(getResources(), R.drawable.helicopter), 65, 13, 3);
        //load high score
        SharedPreferences prefs=this.getContext().getSharedPreferences("BEST",Context.MODE_PRIVATE);
        best=prefs.getInt("key",0); //0 is default value
        smoke = new ArrayList<SmokePuff>();
        missiles = new ArrayList<Missile>();
        topborder =new ArrayList<TopBorder>();
        botborder=new ArrayList<BotBorder>();
        smokeStartTime = System.nanoTime();
        missileStartTime = System.nanoTime();

        //game loop
        thread.setRunning(true);
        thread.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (!player.getPlaying()) {
                player.setPlaying(true);
                player.setUp(true);
            } else {
                player.setUp(true);
            }
            return true;
        }
        if (event.getAction() == MotionEvent.ACTION_UP) {
            player.setUp(false);
            return true;
        }
        return super.onTouchEvent(event);
    }

    public void update() {
        if (player.getPlaying()) {
            bg.update();
            player.update();

            //calculate threshold of height
            maxBorderHeight =30+player.getScore()/progressDenom;
            if(maxBorderHeight> HEIGHT/4)maxBorderHeight=HEIGHT/4;
            minBorderHeight = 5+player.getScore()/progressDenom;

            //check bottom border collision
            for(int i=0; i<botborder.size();i++)
            {
                if(collision(botborder.get(i),player))
                    player.setPlaying(false);
            }

            //check top border collision
            for(int i=0; i<topborder.size();i++)
            {
                if(collision(topborder.get(i),player))
                    player.setPlaying(false);
            }

            //update top and bottom border
            this.updateTopBorder();
            this.updateBottomBorder();


            //missiles on timer
            long missileElapsed = (System.nanoTime() - missileStartTime) / 1000000;
            if (missileElapsed > (2000 - player.getScore() / 4)) {

                if (missiles.size() == 0) {
                    missiles.add(new Missile(BitmapFactory.decodeResource(getResources(), R.drawable.missile),
                            WIDTH + 10, HEIGHT / 2, 45, 15, player.getScore(), 13));
                } else {
                    missiles.add(new Missile(BitmapFactory.decodeResource(getResources(), R.drawable.missile),
                            WIDTH + 10, (int) (rand.nextDouble() * (HEIGHT -(maxBorderHeight*2))+maxBorderHeight), 45, 15, player.getScore(), 13));
                }
                missileStartTime = System.nanoTime();
            }

            //missile loop & check collision
            for (int i = 0; i < missiles.size(); i++) {
                missiles.get(i).update();
                if (collision(missiles.get(i), player)) {
                    missiles.remove(i);
                    player.setPlaying(false);
                    break;
                }
                //remove missile if out of screen
                if (missiles.get(i).getX() < -100) {
                    missiles.remove(i);
                    break;
                }
            }

            //smokepuffs on timer
            long elapsed = (System.nanoTime() - smokeStartTime) / 1000000;
            if (elapsed > 120) {
                smoke.add(new SmokePuff(player.getX(), player.getY() + 10));
                smokeStartTime = System.nanoTime();
            }
            for (int i = 0; i < smoke.size(); i++) {
                smoke.get(i).update();
                if (smoke.get(i).getX() < -10) {
                    smoke.remove(i);
                }
            }
        }
        else {
            newGameCreated=false;
            if (!newGameCreated) {
                newGame();
            }
        }
    }

    public boolean collision(GameObject a, GameObject b)
    {
        if (Rect.intersects(a.getRectangle(), b.getRectangle())) {
            return true;
        }
        return false;
    }


    @Override

    public void draw(Canvas canvas)
    {
        final float scalefactorX =(float)getWidth()/(WIDTH*1.f);
        final float scalefactorY =(float) getHeight()/(HEIGHT*1.f);


        if(canvas!=null)
        {
            final int savedstate =canvas.save();
            canvas.scale(scalefactorX,scalefactorY);
            bg.draw(canvas);
            player.draw(canvas);
            for (SmokePuff sp : smoke) {
                sp.draw(canvas);
            }

            for (Missile m : missiles) {
                m.draw(canvas);
            }

            //draw top borders
            for(TopBorder tb:topborder) {
                tb.draw(canvas);
            }
            //draw bottom borders
            for(BotBorder bb:botborder) {
                bb.draw(canvas);
            }
            drawText(canvas);
            canvas.restoreToCount(savedstate);
        }
    }
    public void updateTopBorder() {
        //every 50 pts,insert random top blocks
        if (player.getScore() % 50 == 0) {
            topborder.add(new TopBorder(BitmapFactory.decodeResource(getResources(), R.drawable.brick1),
                    topborder.get(topborder.size() - 1).getX() + 20, 0, (int) ((rand.nextDouble() * (maxBorderHeight)) + 1)));
        }
        for (int i = 0; i < topborder.size(); i++) {
            topborder.get(i).update();
            if (topborder.get(i).getX() < 20) {
                topborder.remove(i); //replace by adding new one
                if (topborder.get(topborder.size() - 1).getHeight() >= maxBorderHeight) {
                    topDown = false;
                }
                if (topborder.get(topborder.size() - 1).getHeight() <= minBorderHeight) {
                    topDown = true;
                }
                //new border added have larger height
                if (topDown) {
                    topborder.add(new TopBorder(BitmapFactory.decodeResource(getResources(),
                            R.drawable.brick1), topborder.get(topborder.size() - 1).getX() + 20, 0, topborder.
                            get(topborder.size() - 1).getHeight() + 1));
                } else {
                    topborder.add(new TopBorder(BitmapFactory.decodeResource(getResources(),
                            R.drawable.brick1), topborder.get(topborder.size() - 1).getX() + 20, 0, topborder.
                            get(topborder.size() - 1).getHeight() - 1));
                }
            }
        }
    }

    public void updateBottomBorder() {
        //every 40 pts insert random bottom blocks
        if (player.getScore() % 40 == 0) {
            botborder.add(new BotBorder(BitmapFactory.decodeResource(getResources(), R.drawable.brick1),
                    botborder.get(botborder.size() - 1).getX() + 20, (int) ((rand.nextDouble() * (maxBorderHeight)) +
                    (HEIGHT - maxBorderHeight))));
        }

        //update bottom border

        for (int i = 0; i < botborder.size(); i++) {
            botborder.get(i).update();
            //determine if border will move up or down
            if (botborder.get(i).getX() < -20) {
                botborder.remove(i); //replace by adding new one

                if (botborder.get(botborder.size() - 1).getHeight() >= maxBorderHeight) {
                    botDown = false;
                }
                if (botborder.get(botborder.size() - 1).getHeight() <= minBorderHeight) {
                    botDown = true;
                }
                //new border added have larger height
                if (botDown) {
                    botborder.add(new BotBorder(BitmapFactory.decodeResource(getResources(),
                            R.drawable.brick1), botborder.get(botborder.size() - 1).getX() + 20, botborder.
                            get(botborder.size() - 1).getY() + 1));
                } else {
                    botborder.add(new BotBorder(BitmapFactory.decodeResource(getResources(),
                            R.drawable.brick1), botborder.get(botborder.size() - 1).getX() + 20, botborder.
                            get(botborder.size() - 1).getY() - 1));
                }
            }
        }
    }
    public void newGame()
    {
        botborder.clear();
        topborder.clear();
        missiles.clear();
        smoke.clear();

        minBorderHeight=5;
        maxBorderHeight=30;
        player.resetDY();

        player.resetScore();
        player.setY(HEIGHT/2);

        //create initial borders
        //initial top borders
        for(int i=0; i*20<WIDTH +40;i++)
        {
            if(i==0)//first border
            {
                topborder.add(new TopBorder(BitmapFactory.decodeResource(getResources(),R.drawable.brick1),
                        i*20,0,10));

            }
            else//adding borders
            {
                topborder.add(new TopBorder(BitmapFactory.decodeResource(getResources(),R.drawable.brick1),
                        i*20,0,topborder.get(i-1).getHeight()+1));

            }
        }
        //initial bottom borders

        for(int i=0; i*20<WIDTH +40;i++)
        {
            if(i==0)
            {
                botborder.add(new BotBorder(BitmapFactory.decodeResource(getResources(),R.drawable.brick1),
                        i*20,HEIGHT-minBorderHeight));

            }
            else
            {
                botborder.add(new BotBorder(BitmapFactory.decodeResource(getResources(),R.drawable.brick1),
                        i*20,botborder.get(i-1).getY()-1));

            }
        }
        newGameCreated =true;
    }
    public void drawText(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setTextSize(30);
        if (!player.getPlaying()) {
            Paint paint1 = new Paint();
            paint1.setTextSize(40);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText("PRESS TO START:", WIDTH / 2 - 50, HEIGHT / 2, paint1);

            paint1.setTextSize(20);
            canvas.drawText("PRESS AND HOLD TO GO UP", WIDTH / 2 - 50, HEIGHT / 2 + 20, paint1);
            canvas.drawText("RELEASE TO GO DOWN:", WIDTH / 2 - 50, HEIGHT / 2 + 40, paint1);
        }
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText("DISTANCE:" + (player.getScore() * 3), 10, HEIGHT - 10, paint);
        canvas.drawText("BEST:" + best, WIDTH - 215, HEIGHT - 10, paint);


    }
}

