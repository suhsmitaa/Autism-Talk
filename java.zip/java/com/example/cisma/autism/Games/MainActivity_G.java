package com.example.cisma.autism.Games;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.cisma.autism.Games.catch_ball.Catchball_Main;
import com.example.cisma.autism.Games.helicopter.Helicopter_Fly;
import com.example.cisma.autism.R;

public class MainActivity_G extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.games);
    }

    public void OpenBall(View view)
    {
        Intent i=new Intent(MainActivity_G.this,Catchball_Main.class);
        startActivity(i);
    }

    public void OpenHelicopter(View view)
    {
       Intent i=new Intent(MainActivity_G.this, Helicopter_Fly.class);
        startActivity(i);
    }
    public void OpenMines(View view)
    {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.example.hp.minesweeper");
        if(launchIntent!=null)
        {
            startActivity(launchIntent);
        }
    }
    public void OpenSnake(View view)
    {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.example.hp.snake");
        if(launchIntent!=null)
        {
            startActivity(launchIntent);
        }
    }
    public void OpenSudoku(View view)
    {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("mhgr.no.sudoku");
        if(launchIntent!=null)
        {
            startActivity(launchIntent);
        }
    }
    public void OpenWords(View view)
    {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.example.hp.wordsplay");
        if(launchIntent!=null)
        {
            startActivity(launchIntent);
        }
    }
}
