package com.example.cisma.autism;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.cisma.autism.Album.Imagelistact;
import com.example.cisma.autism.Album.MainActivity_A;
import com.example.cisma.autism.Chat.ChatActivity;
import com.example.cisma.autism.Games.MainActivity_G;
import com.example.cisma.autism.Paint.MainActivity_P;
import com.example.cisma.autism.Picturetalk.Picture_Talk;
import com.example.cisma.autism.Quiz.MainActivity_Q;
import com.example.cisma.autism.Speech.MainActivity_S;
import com.example.cisma.autism.Start.Login;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    Button paint,quiz,album,games,chat,picturtalk;

    private FirebaseAuth firebaseAuth;
   TextView username;

    public static String LoggedIn_User_Email;

    public static int Device_Width;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth =  FirebaseAuth.getInstance();
        picturtalk=(Button)findViewById(R.id.talk);
        paint=(Button)findViewById(R.id.drawing);
        quiz=(Button)findViewById(R.id.quiz);
        album=(Button)findViewById(R.id.album);
        games=(Button)findViewById(R.id.games);
        chat=(Button)findViewById(R.id.chat);


        username=(TextView) findViewById(R.id.welcome);




        firebaseAuth = FirebaseAuth.getInstance(); // important Call
        //Again check if the user is Already Logged in or Not

        if(firebaseAuth.getCurrentUser() == null)
        {
            //User NOT logged In
            this.finish();
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
        }





        //Fetch the Display name of current User
        FirebaseUser user = firebaseAuth.getCurrentUser();
        Log.d("LOGGED", "FirebaseUser: " + user);

        if (user != null) {
            username.setText("Welcome, " + user.getDisplayName());



            LoggedIn_User_Email =user.getEmail();




        }

        DisplayMetrics metrics = getApplicationContext().getResources().getDisplayMetrics();
        Device_Width = metrics.widthPixels;






        paint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MainActivity_P.class);
                startActivity(i);
            }
        });

        quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MainActivity_Q.class);
                startActivity(i);
            }
        });

        album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Imagelistact.class);
                startActivity(i);
            }
        });

        games.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MainActivity_G.class);
                startActivity(i);
            }
        });



        picturtalk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Picture_Talk.class);
                startActivity(i);

            }
        });

        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,ChatActivity.class);
                startActivity(i);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id==R.id.logout){
            firebaseAuth.signOut();
            finish();
            Intent i =new Intent(MainActivity.this, Login.class);
            startActivity(i);
        }
        else if(id==R.id.action_settings){
            Intent i =new Intent(MainActivity.this, MainActivity_S.class);
            startActivity(i);
        }
        else if(id==R.id.picture){
            Intent i =new Intent(MainActivity.this, MainActivity_A.class);
            startActivity(i);
        }


        return super.onOptionsItemSelected(item);
    }


}
